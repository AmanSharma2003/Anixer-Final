const express = require("express");
const app = express();
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const path = require("path");
const hbs = require('hbs');



var partialpath = path.join(__dirname, "./template/partials");

hbs.registerPartials(partialpath);

app.set('view engine','hbs')



app.use(express.static('public'));
const url = "mongodb://localhost:27017/anixer";

mongoose
  .connect(url)
  .then(function () {
    console.log("Connection to DB successful");
  })
  .catch(function (err) {
    console.log("there was an error");
  });

  const userSchema = new mongoose.Schema({
    username: {
      type: String,
      required: true,
      unique: true,
    },
    email: {
      type: String,
      unique: true,
    },
    password: {
      type: String,
      required: true,
    },
  });
  
  
  
  const users = mongoose.model("User", userSchema);

app.use(bodyParser.urlencoded({ extended: false }));

app.use(express.static(path.join(__dirname, "public")));

app
  .route("/login")
  .get(function (req, res) {
    res.render("login");
  })
  .post(function (req, res) {

    if(req.body.username){
        const username = req.body.username;
        const email = req.body.email;
        const password = req.body.password;

        var user = new users({
          username: username,
          email: email,
          password: password,
        });
        user.save(function (err, user) {
          if (err) {
            console.log("error ", err);
          } else {
            console.log(username);
          }
    
          res.redirect("/login");
        });
    }
    else{
            const loginname = req.body.loginname;
            const loginpass = req.body.loginpass;
        console.log(loginname)
            users.findOne({ email: loginname }, function (err, user) {
              if (err) {
                console.log("error");
            
              }
              if (user) {
                if (user.password == loginpass) {
              
                  res.redirect("/");
                } else {
                  return res.json({ error: "user does not exist" });
                }
              } else {
                console.log("user not found");
              }
            });
    }
    
    
    
  });

app.get("/categorie_final",function (req, res) {
res.render("categorie_final")
  })

app.get("/dragonballz",function (req, res) {
res.render("dragonballz")
  })

app.get("/hunteranime",function (req, res) {
res.render("hunteranime")
  })

app.get("/dragonballsuper",function (req, res) {
res.render("dragonballsuper")
})
    
app.get("/ichigo",function (req, res) {
res.render("ichigo")
})
    
app.get("/jjkanime",function (req, res) {
res.render("jjkanime")
})

app.get("/Naruto shippuden",function (req, res) {
res.render("Naruto shippuden")
})

app.get("/top_3",function (req, res) {
res.render("top_3")
})

app.get("/", function (req, res) {
res.render("index");
});

app.all("*", (req, res) => {
res.status(404).send("Resource not found");
});

app.listen(3000, function () {
  console.log("listening on port 3000");
});