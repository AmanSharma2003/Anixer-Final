function populate() {
	if(quiz.isEnded()) {
		showScores();
	} else {
		// show question
		var element = document.getElementById('question');
		element.innerHTML = quiz.getQuestionIndex().text; 
 
 
 
		var choices = quiz.getQuestionIndex().choices;
 
 
 
 
		for (var i= 0; i < choices.length; i++) {
			var element = document.getElementById('choice' + i);//choice 0
			element.innerHTML = choices[i]; //set choice 0 
			guess("btn" + i, choices[i]);
 
		}
 
		showProgress();
	}
}
 
function guess(id, guess) {
	var button = document.getElementById(id);
	button.onclick = function() {
		quiz.guess(guess);
		populate();
	}
}
 
 
function showProgress() {
	var currentQuestionNumber = quiz.questionIndex + 1;
	var element = document.getElementById("progress");
	element.innerHTML = "Question " + currentQuestionNumber + " of " + quiz.questions.length;
 
}
 
 
 
function showScores() {
	var gameOverHtml = "<h1>Result</h1>";
	gameOverHtml += "<h2 id='score'>Score: " + quiz.score + "</h2>";
	var element = document.getElementById("quiz");
	element.innerHTML = gameOverHtml;
 
}
 
 
 
 
var questions = [
	new Question("What is actually manga?", ["A form of comics", "A form of animation", "A form of video game", " Moving images"], "A form of animation"),
	new Question("In the first season of In Sword Art Online, what is the black blade used by Kirito called??", ["The Elucidator", "Blue Dragon", "Dawn", "Rising Sun"], "The Elucidator"),
	new Question("In the anime Dragon Ball, what can you do after collecting all seven dragon balls?", ["To fulfil your wishes", "To become immortal", "To rule the world", "None of the above"], "To fulfil your wishes"),
	new Question("What does ther term getsuga tenshou mean?", ["One above all", "Water", "A blade", "Piercer of Heaven"], "Piercer of Heaven"),
	new Question("What does bankai mean?", ["Bones", "Flow the power", "Become unstoppable", "Awaken the dead one "], "Awaken the dead one")
];
 
 
 
 
 
 
 
//slot in the quiz object instance
 
var quiz = new Quiz(questions);
 
populate();
 